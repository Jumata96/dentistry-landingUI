# Rediseño — Clínica Dental (React + Vite + Tailwind)

Este proyecto aplica un rediseño completo enfocado en UX/UI moderno, accesible y de alto rendimiento.

## Stack
- React 18 + Vite 5
- Tailwind CSS v4
- React Router 6
- Sin dependencias pesadas; componentes UI reutilizables (Button, Card, Section, Container).

## Ejecutar
```bash
npm install
npm run dev
```
## Estructura
- `src/components/ui`: primitivas reutilizables
- `src/components/layout`: Header y Footer accesibles con menú móvil
- `src/pages`: Home, Services, ServiceDetail, NotFound
- `public/data`: datos JSON (servicios, horarios, testimonios)

## Notas UX
- Enfoque en acciones clave (Reservar, Ver servicios)
- Jerarquía clara, tipografía Inter, contraste AA
- Navegación sticky, enlaces de salto, focus styles
- Formulario simple y comprensible
